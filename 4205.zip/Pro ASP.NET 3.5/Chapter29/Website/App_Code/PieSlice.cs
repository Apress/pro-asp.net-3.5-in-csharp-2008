﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public class PieSlice
{
    private float dataValue;
    private string caption;

    public float DataValue
    {
        get { return dataValue; }
        set { dataValue = value; }
    }

    public string Caption
    {
        get { return caption; }
        set { caption = value; }
    }

    public PieSlice(string caption, float dataValue)
    {
        Caption = caption;
        DataValue = dataValue;
    }

    public override string ToString()
    {
        return Caption + " (" + DataValue.ToString() + ")";
    }

}
