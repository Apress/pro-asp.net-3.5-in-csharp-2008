using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Apress.CustomInstaller
{
  [RunInstaller(true)]
  public partial class DbInstaller : System.Configuration.Install.Installer
  {
    public DbInstaller()
    {
      InitializeComponent();
    }

    protected override void OnBeforeInstall(System.Collections.IDictionary savedState)
    {
      MessageBox.Show("Executing custom database action");

      try
      {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"data source=(local)\SQL2005;integrated security=SSPI;initial catalog=master";
        conn.Open();

        try
        {
          // Create the database 
          SqlCommand cmd = new SqlCommand();
          cmd.Connection = conn;
          cmd.CommandText = "CREATE DATABASE TestDb";
          cmd.ExecuteNonQuery();

          // Now close the connection and connect to the created TestDb database to create the tables
          // ...
        }
        finally
        {
          conn.Close();
        }
      }
      catch (Exception ex)
      {
        MessageBox.Show("Exception: " + ex.Message);
        base.Rollback(savedState);
      }

      base.OnBeforeInstall(savedState);
    }

    protected override void OnBeforeUninstall(System.Collections.IDictionary savedState)
    {
      try
      {
        SqlConnection conn = new SqlConnection();
        conn.ConnectionString = @"data source=(local)\SQL2005;integrated security=SSPI;initial catalog=master";
        conn.Open();

        try
        {
          // Create the database 
          SqlCommand cmd = new SqlCommand();
          cmd.Connection = conn;
          cmd.CommandText = "DROP DATABASE TestDb";
          cmd.ExecuteNonQuery();
        }
        finally
        {
          conn.Close();
        }
      }
      catch
      {
        base.Rollback(savedState);
      }

      base.OnBeforeUninstall(savedState);
    }
  }
}