﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DatabaseComponent;
using System.Collections.Generic;

public partial class LinqToSql : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LinqNorthwindDB db = new LinqNorthwindDB();

        // LINQ to SQL query followed by LINQ to Objects filter.
        //IQueryable<EmployeeDetails> table = db.GetEmployees();
        //IEnumerable<EmployeeDetails> matches = from employee in table.AsEnumerable<EmployeeDetails>()
        //  where employee.LastName.StartsWith("D")
        //  select employee;

        // LINQ to SQL query with where clause.
        // This pattern forces the database query to run outside of the
        // database component, which is dangerous.
        IQueryable<EmployeeDetails> table = db.GetEmployees();
        IEnumerable<EmployeeDetails> matches = from employee in table
                                               where employee.LastName.StartsWith("D")
                                               select employee;

        grid.DataSource = matches;
        grid.DataBind();
    }
}
