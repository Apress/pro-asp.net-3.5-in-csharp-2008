﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DatabaseComponent;
using System.Text;

public partial class LinqToSqlRelationships : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        LinqNorthwindDB db = new LinqNorthwindDB();
        
        //Order ord = db.GetOrder(10643);
        //ord.OrderDate = DateTime.Now;     
        //Order ord2 = db.GetOrder(10643);

        StringBuilder sb = new StringBuilder();
        foreach (Customer customer in db.GetCustomers())
        {
            sb.Append(customer.CompanyName);
            sb.Append("<br />");

            foreach (Order order in customer.Orders)
            {
                sb.Append(order.OrderID.ToString());
                sb.Append(" - ");
                sb.Append(order.OrderDate.Value.ToShortDateString());
                sb.Append("<br />");
            }
            sb.Append("<hr /><br />");
        }
        lblInfo.Text = sb.ToString();
    }
}
